#!/bin/bash


#SBATCH -J Cat_Bins
#SBATCH -e M-%A-error
#SBATCH -o M-%A-out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH -p shared-bigmem
#SBATCH -t 12:00:00
#SBATCH --mem=250000
#SBATCH --mail-type=ALL
#SBATCH --mail-user=jaspreet.saini@etu.unige.ch


diamond blastx \
        --query /home/users/s/saini7/scratch/MS2/Anvio_June_Refine_June_28_Final/SAMPLES-SUMMARY_Refined_29_June/bin_by_bin/Bin_40/Bin_40-contigs_non_chlorophyta_removed_29_June.fa \
        --db /home/users/s/saini7/scratch/BLAST/nr_diamond_with_taxid_2021-07-24.dmnd \
        --outfmt 6 qseqid staxids bitscore qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue \
        --sensitive \
        --max-target-seqs 1 \
        --evalue 1e-25 \
        --threads 16 \
        > /home/users/s/saini7/scratch/MS2/Anvio_June_Refine_June_28_Final/Blobtools_files/Bin_40-contigs_non_chlorophyta_removed_blast.out
